API_ID =  # Not in quotes
API_HASH = " " # in quotes ""

# delay between connections to accounts
ACC_DELAY = [5, 15]

# folder with sessions (do not change)
WORKDIR = "sessions/"

# Using proxy
USE_PROXY = False # True/False


PROXY_TYPE = "socks5"

# Full link to your Sessions folder
SESSIONS_PATH = "YOUR PATH TO SESSIONS"

# How many points from the game
POINTS = [255, 270] #[min, max]

# Spend diamonds
SPEND_DIAMONDS = True # True/False

# Sleep between games
SLEEP_GAME_TIME = [9,21] #[min,max]

# mini sleep
MINI_SLEEP = [3,7] #[min,max]

# add sleep after 8 hours
SLEEP_8HOURS = [60*60,120*60] #[min,max] seconds

hello ='''
 
▒█▀▀█ █░░ █░░█ █▀▄▀█ ▒█▀▀█ █▀▀█ ▀▀█▀▀ 
▒█▀▀▄ █░░ █░░█ █░▀░█ ▒█▀▀▄ █░░█ ░░█░░ 
▒█▄▄█ ▀▀▀ ░▀▀▀ ▀░░░▀ ▒█▄▄█ ▀▀▀▀ ░░▀░░
                                          
'''
